﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Threading;
using System.IO.Ports;
using System.IO;

namespace PiDistSensor
{
    class Program
    {
        const string FILE_PATH = @"/home/pi/DistanceSensor/";
        const string FILE_NAME = @"PoolLog.txt";

        static void Main(string[] args)
        {
            //sets the number of data points taken per entry
            const int TRIAL_SIZE = 20;          

            try
            {
                SerialPort ardP = new SerialPort("/dev/ttyACM0", 9600, Parity.None, 8);   //serial port for pi             
                //SerialPort ardP = new SerialPort("COM3", 9600, Parity.None, 8);           //serial port on pc

                decimal[] rawData = new decimal[TRIAL_SIZE];

                ardP.Open(); //open serial port
                Thread.Sleep(500); //delay 500 millis

                for (int i = 0; i < TRIAL_SIZE; i++)
                {                    
                    ardP.WriteLine("");                 //sends command to arduino to take reading
                    Thread.Sleep(100);                  //delay to allow reading to complete
                    rawData[i] = ReadSerial(ardP);      //calls read function and returns distance
                    
                    if (rawData[i] == 0)                //if pi reads a distance of 0, data is thrown out
                        i--;                                        
                } 
                
                WriteToFile(Decimal.Round(rawData.Average(),1).ToString());      //average of of data points rounded to mm written to file                       
             
                ardP.Close();                           //serial port closed
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();                
            }
        }

        private static decimal ReadSerial(SerialPort sp)
        {                   
            string serialDat = "";            
            byte[] buf = new byte[sp.BytesToRead];
            
            if (sp.BytesToRead == 0)        //if 0 bytes to read, serial data is not ready yet
            {
                Thread.Sleep(100);
                return 0;
            }           
            sp.Read(buf, 0, buf.Length);    //reads serial from arduino           

            foreach (Byte b in buf)         //constructs the distance string one byte at a time
            {                
                if(Convert.ToChar(b) != '\n')       //checks for newline character and removes it from end of string
                    serialDat += Convert.ToChar(b); 
            }
            
            return Convert.ToDecimal(serialDat);    //converts distance string to decimal and returns value
        }

        private static void WriteToFile(string distance)
        {
            string fullPath = FILE_PATH + FILE_NAME;

            using (StreamWriter sw = new StreamWriter(fullPath, append:true))   //create streamwrite
            {           
                sw.WriteLine(distance + " cm " + DateTime.Now.ToString("MM/dd/yyyy HH:mm"));             //write to text file
            }
            return;
        }        

    }
}
